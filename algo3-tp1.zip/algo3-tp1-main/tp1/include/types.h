#ifndef TYPES_H_
#define TYPES_H_

#include <tuple>

typedef std::pair<int, int> pair;
typedef std::vector<std::vector<int>> matrix;

#endif /* TYPES_H_ */